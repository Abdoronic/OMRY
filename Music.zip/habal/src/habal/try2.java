package habal;
import java.io.*;

import javazoom.jl.player.Player;

public class try2
{
  public static void main(String[] args) 
  throws Exception
  {
   FileInputStream f= new FileInputStream("4.mp3"); //choose form 3 or 4
   Player p =new Player(f);
   System.out.println("the song is playing...");
   p.play();
  }
}