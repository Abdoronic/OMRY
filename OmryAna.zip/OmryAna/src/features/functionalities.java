package features;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.nio.channels.FileChannel;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

public class functionalities {
	private static String organizer(String result) {
		if(result.contains("make alarm at")) {
//			int x=StoI(result);
//			System.out.println(result+"         " +x);
			
		}
		if(result.equals("what is the time now")) {
				return time();
		}
		else if(result.substring(0, 4).equals("call")) {
			return "calling "+result.substring(5, result.length());
		}
		else if(result.equals("good morning")||result.equals("good afternoon")||result.equals("good evening")||result.equals("hey")||result.equals("hello")) {
			return "hello";
		}
		else if(result.equals("tell me a joke")) {
			return joke();
		}
		
		return "what are you saying";
		
	}
	
	private static String joke() {
		String [] x= {"Today at the bank, an old lady asked me to help check her balance. So I pushed her over",
				"I bought some shoes from a drug dealer. I don't know what he laced them with, but I've been tripping all day",
				"I'm so good at sleeping. I can do it with my eyes closed",
				"My boss told me to have a good day.. so I went home",
				"Why do blind people hate skydiving? It scares the hell out of their dogs",
				"What do you call a guy with a rubber toe? Roberto"," know a lot of jokes about unemployed people but none of them work"};
		
		return x[(int)(Math.random() * ((5 - 0) + 1))];
	}

	private static String time() {
		DateFormat dateFormat = new SimpleDateFormat("HH:mm");
		Date date = new Date();
		String x=dateFormat.format(date);
		int y=Integer.parseInt(x.substring(0, 2));
		return  dateFormat.format(date);
	}

	public static void main(String[] args) throws Exception {
		while(true) {		
			try {
				BufferedReader br = new BufferedReader(new FileReader("C:/Users/abdel/.spyder-py3/Output.TXT"));
				while(br.ready()) {
					String result=br.readLine();
					if(result.equals("") || result.charAt(0)=='$')
						continue;
					if(result.equals("bye bye")) {
						System.out.println("You said: " + result + "\n");
						FileChannel.open(Paths.get("C:/Users/abdel/.spyder-py3/Output.TXT"), StandardOpenOption.WRITE).truncate(0).close();
						try(PrintWriter out = new PrintWriter(new BufferedWriter(new FileWriter("C:/Users/abdel/.spyder-py3/Output.TXT", true)))) {
						    out.println("!see you soon sir");
						} catch (IOException e) {
						    System.err.println(e);
						}
						return;
					}
					else {
						System.out.println("You said: " + result + "\n");
						String say = organizer(result);
						System.out.println("done");
					FileChannel.open(Paths.get("C:/Users/abdel/.spyder-py3/Output.TXT"), StandardOpenOption.WRITE).truncate(0).close();
					try(PrintWriter out = new PrintWriter(new BufferedWriter(new FileWriter("C:/Users/abdel/.spyder-py3/Output.TXT", true)))) {
					    out.println("$"+say);
					} catch (IOException e) {
					    System.err.println(e);
					}
					}
				}
			} catch (FileNotFoundException e) {
				e.printStackTrace();
			}
		
	}
			
	}

}
